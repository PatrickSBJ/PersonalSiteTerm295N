﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.



function setupPage()
{
    var playerForm = document.getElementById("playerForm");
    playerForm.remove();

    var mainDiv = document.getElementById("mainDiv");
}
    function checkScores() {
        var score = 0;

    if (document.getElementById(""))
}


